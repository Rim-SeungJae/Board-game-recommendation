// fadein home image
$(document).ready(function(){
  $(".home-image").fadeIn(3000)
});
